import sys
import random

IUPAC = ["A", "C", "G", "T", "U", "-", "R", "Y", "S", "W", "K", "M", "B", "V", "D", "H"]

for x in range(int(sys.argv[1])):
    seq = "".join(random.choices(IUPAC, weights = [.15, .15, .15, .15, .15, .1, 0.015,
                                           0.015, 0.015, 0.015, 0.015, 0.015,
                                           0.015, 0.015, 0.015, 0.015], k=int(sys.argv[2])))
    print(">{}\n{}".format(x, seq))
